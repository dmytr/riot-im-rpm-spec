Vector is written mainly by the Vector team, building upon the Matrix React
SDK. Vector also welcomes external contributions. Third party contributors
include:

* Nolan Darilek (https://github.com/ndarilek)
  Accessibility and semantic markup contributions

* https://github.com/neko259
  Improved scrollbar CSS

* Florent VIOLLEAU (https://github.com/floviolleau) <floviolleau at gmail dot com>
  Improve README.md for a better understanding of installation instructions

* Michael Telatynski (https://github.com/t3chguy)
  Improved consistency of inverted elements in dark theme across browsers
